<template>
<div class="chart">
  <Chart></Chart>
</div>
</template>

<script>
import Chart from "./psiLineChart.js"

export default {
name: "psiLineChart",
  components: {
    Chart
  }
}
</script>

<style scoped>

</style>