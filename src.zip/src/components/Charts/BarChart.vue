<template>
  <div class="chart">
    <chart></chart>
  </div>
</template>

<script>
import Chart from "./BarChart.js";

export default {
  components: {
    Chart
  }
};
</script>

<style>
</style>